//
//  ContentView.swift
//  CardViewTest
//
//  Created by USER on 2022/12/01.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var manager: CardViewMananger
    
    // MatchedGeometryEffect
    @Namespace var animation
    // @State var scale: CGFloat = 0
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(spacing: 0) {
                TitleView()
                    .padding(.horizontal)
                    .padding(.bottom)
                    .opacity(manager.showDetailPage ? 0 : 1)
                
                ForEach(manager.getCardItems(), id: \.self) { item in
                    Button {
                        withAnimation(.interactiveSpring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.7)) {
                            manager.currentItem = item
                            manager.setShowDetailState(true)
                        }
                    } label: {
                        CardView(cardInfo: item, animation: animation)
                            .scaleEffect(manager.currentItem == item && manager.showDetailPage ? 1 : 0.93)
                    }
                    .buttonStyle(ScaledButtonStyle())
                    .opacity(manager.showDetailPage ? (manager.configureTitleOffset(item: item) ? 1 : 0) : 1)
                }
            }
            .padding(.vertical)
        }
        .background(Color("BackgroundColor"))
        .overlay {
            if let currentItem = manager.currentItem, manager.showDetailPage {
                CardDetailView(cardInfo: currentItem, animation: animation)
                    .ignoresSafeArea(.container, edges: .top)
                    /*.gesture(DragGesture(minimumDistance: 0)
                        .onChanged(onChanged(value:))
                        .onEnded(onEnded(value:)))
                    .scaleEffect(scale)*/
            }
        }
    }
    
    @ViewBuilder
    func TitleView() -> some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 0) {
                Text("test")
                    .font(.callout)
                    .foregroundColor(.gray)
                
                Text("aa")
                    .font(.largeTitle.bold())
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            Button {
                
            } label: {
                Image(systemName: "person.circle.fill")
                    .font(.largeTitle)
            }
        }
    }
    
    /*func onChanged(value: DragGesture.Value) {
        let scale = value.translation.height / UIScreen.main.bounds.height
        self.scale = scale
    }
    
    func onEnded(value: DragGesture.Value) {
        withAnimation(.spring()) {
            self.scale = 1
        }
    }*/
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


