//
//  CardDetailView.swift
//  CardViewTest
//
//  Created by USER on 2022/12/11.
//

import SwiftUI

struct CardDetailView: View {
    @EnvironmentObject var manager: CardViewMananger
    
    @State var scrollOffset: CGFloat = 0
    var cardInfo: CardInfo
    var animation: Namespace.ID
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                CardView(cardInfo: cardInfo, animation: animation)
                    .scaleEffect(manager.animateView ? 1 : 0.93)
             
                VStack(spacing: 15) {
                    Text(cardInfo.appDescription ?? "")
                        .multilineTextAlignment(.leading)
                        .lineSpacing(10)
                        .padding(.bottom, 20)
                }
                .padding()
                .opacity(manager.animateContent ? 1 : 0)
                .scaleEffect(manager.animateView ? 1 : 0, anchor: .top)
                .offset(y: scrollOffset > 0 ? scrollOffset : 0)
            }
            .offset(y: scrollOffset > 0 ? -scrollOffset : 0)
            .scrollDown(offset: $scrollOffset)
        }
        .overlay(alignment: .topTrailing, content: {
            Button {
                withAnimation(.interactiveSpring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.7)) {
                    manager.setAnimateView(state: false)
                    manager.setAnimateContentState(false)
                }
                withAnimation(.interactiveSpring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.7).delay(0.05)) {
                    manager.currentItem = nil
                    manager.setShowDetailState(false)
                }
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
            }
            .padding()
            .padding(.top, safeArea().top)
            .opacity(manager.animateView ? 1 : 0)
        })
        .onAppear {
            withAnimation(.interactiveSpring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.7)) {
                manager.setAnimateView(state: true)
            }
            withAnimation(.interactiveSpring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.7).delay(0.1)) {
                manager.setAnimateContentState(true)
            }
        }
        .transition(.identity)
    }
}

