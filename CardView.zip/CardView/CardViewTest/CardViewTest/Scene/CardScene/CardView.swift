//
//  CardView.swift
//  CardViewTest
//
//  Created by USER on 2022/12/01.
//

import SwiftUI

struct CardView: View {
    @EnvironmentObject var mananger: CardViewMananger
    @Environment(\.colorScheme) var colorScheme
    
    var cardInfo: CardInfo
    var animation: Namespace.ID
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            ZStack(alignment: .topLeading) {
                GeometryReader { geometry in
                    let size = geometry.size
                    
                    Image(cardInfo.imageName ?? "")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: size.width, height: size.height)
                        .clipped()
                        .clipShape(CustomCorner(corners: [.topLeft, .topRight], radius: 15))
                }
                .frame(height: 400)
                
                if colorScheme == .dark {
                    LinearGradient(colors: [
                        .black.opacity(0.5),
                        .black.opacity(0.2),
                        .clear
                    ], startPoint: .top, endPoint: .bottom)
                    .clipShape(CustomCorner(corners: [.topLeft, .topRight], radius: 15))
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(cardInfo.subTitle ?? "")
                        .font(.callout)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    
                    Text(cardInfo.mainTitle ?? "")
                        .font(.largeTitle.bold())
                        .foregroundColor(.white)
                        .multilineTextAlignment(.leading)
                }
                .foregroundColor(.primary)
                .padding()
                .offset(y: mananger.configureTitleOffset(item: cardInfo) ? safeArea().top : 0)
            }
            
            HStack(spacing: 12) {
                Image(cardInfo.imageName ?? "")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(cardInfo.appType ?? "")
                        .font(.caption)
                        .foregroundColor(.gray)
                    
                    Text(cardInfo.appName ?? "")
                        .fontWeight(.bold)
                    
                    Text(cardInfo.appInfo ?? "")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity, alignment: .leading)
                
                Button {
                    
                } label: {
                    Text("GET")
                        .fontWeight(.bold)
                        .foregroundColor(.blue)
                        .padding(.vertical, 8)
                        .padding(.horizontal, 20)
                        .background {
                            Capsule()
                                .fill(.ultraThinMaterial)
                        }
                }
            }
            .padding([.horizontal, .bottom])
        }
        .background {
            RoundedRectangle(cornerRadius: mananger.animateView ? 0 : 15,
                             style: .continuous)
                .fill(Color("CardViewBG"))
        }
        .matchedGeometryEffect(id: cardInfo.id, in: animation)
    }
}
