//
//  File.swift
//  CardViewTest
//
//  Created by USER on 2022/12/11.
//

import Foundation

struct CardInfo: Codable, Hashable {
    var id: Int
    var imageName: String?
    var logoName: String?
    var subTitle: String?
    var mainTitle: String?
    var appType: String?
    var appName: String?
    var appInfo: String?
    var appDescription: String?
}
