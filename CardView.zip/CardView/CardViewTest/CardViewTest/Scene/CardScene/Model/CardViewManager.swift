//
//  CardViewManager.swift
//  CardViewTest
//
//  Created by USER on 2022/12/11.
//

import SwiftUI

class CardViewMananger: ObservableObject {
    
    @Published var cardItems = [CardInfo]()
    @Published var currentItem: CardInfo?
    
    // MatchedGeometryEffect
    @Published var animateView: Bool = false
    @Published var animateContent: Bool = false
    
    @Published var showDetailPage: Bool = false
    
    // @Published var cardScale: CGFloat = 0
    
    init() {
        self.configureCardItems()
    }
    
    private func configureCardItems() {
        cardItems.append(CardInfo(id: 1,
                                  imageName: "applewatch",
                                  logoName: "applewatch",
                                  subTitle: "Apple Arcade",
                                  mainTitle: "You change the Watch Interface",
                                  appType: "Apple Arcade",
                                  appName: "Apple Watch",
                                  appInfo: "Change Apple Interface",
                                  appDescription: getAppDescription()))
        cardItems.append(CardInfo(id: 2,
                                  imageName: "macmini",
                                  logoName: "macmini",
                                  subTitle: "Apple Arcade",
                                  mainTitle: "You change the Mac mini Interface",
                                  appType: "Apple Arcade",
                                  appName: "Mac mini",
                                  appInfo: "Change Apple Interface",
                                  appDescription: getAppDescription()))
    }
    
    fileprivate func getAppDescription() -> String {
        return "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
    }
    
    func getCardItems() -> [CardInfo] {
        return self.cardItems
    }
    
    func setAnimateView(state: Bool) {
        self.animateView = state
    }
    
    func setAnimateContentState(_ state: Bool) {
        self.animateContent = state
    }
    
    func setShowDetailState(_ state: Bool) {
        self.showDetailPage = state
    }
    
    func configureCardOpacity(item: CardInfo) -> Bool {
        if currentItem?.id == item.id {
            return true
        } else {
            return false
        }
    }
    
    func configureTitleOffset(item: CardInfo) -> Bool {
        if currentItem == item && animateView {
            return true
        } else {
            return false
        }
    }
}
