//
//  CardViewTestApp.swift
//  CardViewTest
//
//  Created by USER on 2022/12/01.
//

import SwiftUI

@main
struct CardViewTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(CardViewMananger())
        }
    }
}
